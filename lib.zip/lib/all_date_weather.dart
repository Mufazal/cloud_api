import 'package:flutter/material.dart';

class SingleDayTimeWeather extends StatefulWidget {
  @override
  _SingleDayTimeWeatherState createState() => _SingleDayTimeWeatherState();
}

class _SingleDayTimeWeatherState extends State<SingleDayTimeWeather> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}